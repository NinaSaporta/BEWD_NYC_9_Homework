require 'test_helper'

class MoviesTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
