class Movies < ActiveRecord::Base
end
