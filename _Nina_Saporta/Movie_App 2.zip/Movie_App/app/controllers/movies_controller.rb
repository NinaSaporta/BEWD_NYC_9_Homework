class MoviesController < ApplicationController
def create
  	@movies = Movie.new(params [:title])
  	@movies.save
  	redirect_to @movies
end

  def index
  	@movies= Movies.all
  end
end
