#bookinfo class
class Bookinfo

  attr_accessor :title, :authors, :decription, :preview
  def initialize(title, authors, description, preview)
    @title = title
    @authors = authors
    @description = description
    @preview = preview
  end

  def to_s
  end

end