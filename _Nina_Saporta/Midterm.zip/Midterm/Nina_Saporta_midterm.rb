require 'json'
require 'rest-client'
require 'pry'

require_relative 'lib/bookinfo'

def get_access_key
  return "AIzaSyBUKwL2ClTAaKwn1csWuOOhNgKj5kv3QeA"
end

def user_input
 puts "Please enter a book title to see information and a preview"
 book = gets.to_s
 results = search_book_by_name(book)

 
 results["items"].each do |item|
   book = Bookinfo.new(item["volumeInfo"]["title"], "authors", item["volumeInfo"]["description"], "preview")
 
   puts "Title: #{book.title}"
 end

end

 def search_book_by_name(book)
    
    url = "https://www.googleapis.com/books/v1/volumes?q=#{URI::encode(book)}&key=#{get_access_key}"
	res = JSON.load(RestClient.get(url))
    return res	
	# res["items"].each do |item|

 #      puts "Title: #{item["volumeInfo"]["title"]}"
 #      puts "Desc: #{item["volumeInfo"]["description"]}"
 #      puts "---------------------------------------------"

	# end

	# if res["totalItems"]>0
	#    res["items"]["volumeInfo"].each do |book|
	#    b = {title:book["items"]["volumeInfo"]["title"], author:book["items"]["volumeInfo"]["authors"], description:book["items"]["volumeInfo"]["description"], preview:book["items"]["volumeInfo"]["previewLink"]}
	#    b
	#  else 
	#  puts "Sorry, this title is not available."
	#  next_move
  #end
end

def next_move
  puts "Want to check out another book (y/n)?"
  next_move = gets.strip
  if next_move == "y"
    user_input
  elsif next_move == "n"
    puts "We hope you found a good book!  Bye!"
  else
    puts "Please enter 'y' or 'n' to let us know if you want to check out another book or not!"
  end
end

	# puts "The book #{@title} by #{@authors} is about #{@description}.  To preview the book please click #{@preview}!"
	# next_move

puts "Finding the right book to read can be hard! Well, welcome to the Google Books Preview Generator!  Feel free to search a book by its title and you'll be able to read a description AND preview of the book!"
user_input